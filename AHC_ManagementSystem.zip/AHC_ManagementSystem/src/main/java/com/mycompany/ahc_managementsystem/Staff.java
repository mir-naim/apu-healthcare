package com.mycompany.ahc_managementsystem;

public class Staff extends User {

    public Staff(String ID) {
        super(ID);
    }
    
    // Staff's features here
    //
    //
    //
    //Profile
    
}
