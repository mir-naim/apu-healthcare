package com.mycompany.ahc_managementsystem;

public class Customer extends User {
    
    public Customer(String ID) {
        super(ID);
    }
    
    
}
