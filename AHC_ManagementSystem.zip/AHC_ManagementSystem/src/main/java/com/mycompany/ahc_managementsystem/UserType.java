package com.mycompany.ahc_managementsystem;

public enum UserType {
    STAFF,
    TRAINER,
    CUSTOMER;
    
    public static UserType getUserType(String str)
    {
        switch(str)
        {
            case "STAFF":
                return STAFF;
            case "TRAINER":
                return TRAINER;
            case "CUSTOMER":
                return CUSTOMER;
            default:
                return null;
        }
    }
}
