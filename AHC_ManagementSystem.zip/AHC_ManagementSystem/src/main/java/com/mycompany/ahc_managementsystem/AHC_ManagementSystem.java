package com.mycompany.ahc_managementsystem;

import ahc_managementsystem.Forms.Progress;

public class AHC_ManagementSystem {

    public static void main(String[] args) {
        
        // Main controller here
        
        boolean progressed = false;
        if(!progressed) {
            Progress p = new Progress();
            p.setVisible(true);

        }
    }
}
